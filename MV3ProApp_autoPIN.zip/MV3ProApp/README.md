# MV-3 PRO – Android (auto-PIN 123456, chiffré)

- Ouverture directe (pas de demande PIN)
- Données chiffrées avec PIN fixe 123456
- Build APK via GitHub Actions (voir Actions > Build Android APK)

Étapes : créer repo privé, uploader tout, lancer le workflow, télécharger `app-debug.apk`.
